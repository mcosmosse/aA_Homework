class UsersController < ApplicationController

    def new
        render :new
    end

    def create
        @user = User.new(users_params)

        if @user.save
            redirect_to user_url(@user)
        else
            render :new # still have access to @user instance variable for this view
        end
    end

    private

    def users_params
        params.require(:users).permit(:user_name, :password_digest, :session_token)
    end

end
