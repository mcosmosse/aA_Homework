# == Schema Information
#
# Table name: users
#
#  id              :bigint           not null, primary key
#  user_name       :string           not null
#  password_digest :string           not null
#  created_at      :datetime         not null
#  updated_at      :datetime         not null
#  session_token   :string           not null
#
class User < ApplicationRecord
    validates :user_name, :password_digest, :session_token, presence: true
    validates :user_name, :session_token, uniqueness: true

    def self.find_by_credentials(user_name, password)
        user = User.find_by(user_name: user_name)
        
        if user && user.is_password?(password) #use = if user exist && if the password == password
            user
        else
            nil
        end
    end

    def reset_session_token!
        self.session_token = SecureRandom.urlsafe_base64 #generate random string
        self.save! #save↑
        self.session_token #return it 
    end

    def password=(password)
        @password = password
        self.password_digest = BCrypt::Password.create(password) #password_digest represents salted password
    end

    def is_password?(password)
        BCrypt::Password.new(self.password_digest).is_password?(password) #ask
        # create bcrypt object(type of password object) 
        #returnin bcrypt object 
        #compare (self.password_digest) and is_password?(password)
    end

end
